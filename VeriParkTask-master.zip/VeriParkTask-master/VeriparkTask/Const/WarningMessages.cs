﻿namespace VeriparkTask.Const
{
    public class WarningMessages
    {
        public static string AddCountrySuccess => "Country Successfully Added";
        public static string AddCountryFail => "Country Plan Couldn't Added. Please Check All Information";

        public static string AddSpecialDaySuccess => "Special Day Successfully Added";
        public static string AddSpecialDayFail => "Special Day Couldn't Added. Please Check All Information";
    }
}